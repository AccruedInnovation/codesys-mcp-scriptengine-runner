using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace AccruedInnovation.CodesysMcp.ScriptRunner
{
    internal static class McpServerAutoStarter
    {
        private const string McpAssemblyName =
            "DevelopmentSystemMCPServer.plugin";

        private const string LicenserTypeName =
            "CODESYS.DevelopmentSystemMCPServer.Utilities.Licensing.Licenser";

        private const string EnableCommandTypeName =
            "CODESYS.DevelopmentSystemMCPServer.Commands.EnableMcpServerCommand";

        private const int PollIntervalMilliseconds = 500;
        private const int TimeoutMilliseconds = 120000;
        private const int ProgressLogIntervalMilliseconds = 5000;

        private static readonly object Sync = new object();

        private static Timer? _timer;
        private static Stopwatch? _elapsed;
        private static long _lastProgressLogMilliseconds;
        private static string? _logPath;

        public static string Schedule()
        {
            lock (Sync)
            {
                if (_timer != null)
                {
                    return "MCP Server startup is already scheduled.";
                }

                _logPath = Path.Combine(
                    GetAssemblyDirectory(),
                    "startup-registration.log");
                _elapsed = Stopwatch.StartNew();
                _lastProgressLogMilliseconds = 0;

                var timer = new Timer
                {
                    Interval = PollIntervalMilliseconds
                };
                timer.Tick += OnTimerTick;
                _timer = timer;
                timer.Start();

                WriteLog(
                    "MCP Server startup scheduled. The first check will run " +
                    "after the startup script returns to the CODESYS UI loop.");

                return string.Join(
                    Environment.NewLine,
                    "MCP Server startup scheduled after the startup script returns.",
                    "The server will start when the MCP licenser reports an active license.",
                    "Timeout: " + (TimeoutMilliseconds / 1000) + " seconds.");
            }
        }

        public static string Cancel()
        {
            lock (Sync)
            {
                bool wasScheduled = _timer != null;
                StopTimerLocked();
                if (wasScheduled)
                {
                    WriteLog("Pending MCP Server startup was cancelled.");
                    return "Cancelled pending MCP Server startup.";
                }

                return "No MCP Server startup was pending.";
            }
        }

        public static string ProbeLicenseState(bool forceInitialize)
        {
            LicenseProbe probe = ReadLicenseState(forceInitialize);
            return probe.ToString();
        }

        private static void OnTimerTick(object? sender, EventArgs e)
        {
            lock (Sync)
            {
                if (_timer == null || _elapsed == null)
                {
                    return;
                }

                try
                {
                    // This callback cannot run until the --runscript call has
                    // returned to the Windows message loop. At that point the
                    // normal MCP system initializer should have run. If it has
                    // not, call its own guarded Initialize method rather than
                    // the lower-level private LicenseChecker.CheckLicenses.
                    LicenseProbe probe = ReadLicenseState(forceInitialize: true);
                    long elapsedMilliseconds = _elapsed.ElapsedMilliseconds;

                    if (probe.IsLicensed == true)
                    {
                        StopTimerLocked();
                        try
                        {
                            string result = StartMcpServer();
                            WriteLog(result + " License state: " + probe);
                        }
                        catch (Exception exception)
                        {
                            WriteLog(
                                "MCP Server start failed after the license became " +
                                "active: " + FormatException(exception));
                        }
                        return;
                    }

                    if (elapsedMilliseconds >= TimeoutMilliseconds)
                    {
                        StopTimerLocked();
                        WriteLog(
                            "MCP Server startup timed out while waiting for an " +
                            "active license. Last state: " + probe);
                        return;
                    }

                    if (elapsedMilliseconds - _lastProgressLogMilliseconds >=
                        ProgressLogIntervalMilliseconds)
                    {
                        _lastProgressLogMilliseconds = elapsedMilliseconds;
                        WriteLog(
                            "Still waiting for the MCP license. State: " + probe);
                    }
                }
                catch (Exception exception)
                {
                    long elapsedMilliseconds = _elapsed?.ElapsedMilliseconds ?? 0;
                    WriteLog(
                        "MCP Server deferred-start check failed: " +
                        FormatException(exception));

                    if (elapsedMilliseconds >= TimeoutMilliseconds)
                    {
                        StopTimerLocked();
                    }
                }
            }
        }

        private static LicenseProbe ReadLicenseState(bool forceInitialize)
        {
            Assembly? assembly = FindMcpImplementationAssembly();
            if (assembly == null)
            {
                return new LicenseProbe(
                    null,
                    null,
                    null,
                    false,
                    "MCP implementation assembly is not loaded yet");
            }

            Type? licenserType = assembly.GetType(
                LicenserTypeName,
                throwOnError: false,
                ignoreCase: false);
            if (licenserType == null)
            {
                return new LicenseProbe(
                    null,
                    null,
                    null,
                    false,
                    "MCP licenser type is not available yet");
            }

            const BindingFlags allInstanceFlags =
                BindingFlags.Public |
                BindingFlags.NonPublic |
                BindingFlags.Instance;

            PropertyInfo? instanceProperty = licenserType.GetProperty(
                "Instance",
                BindingFlags.Public | BindingFlags.Static);
            object? licenser = instanceProperty?.GetValue(null, null);
            if (licenser == null)
            {
                return new LicenseProbe(
                    null,
                    null,
                    null,
                    false,
                    "MCP licenser instance is not available yet");
            }

            FieldInfo? initializedField = licenserType.GetField(
                "_initialized",
                allInstanceFlags);
            bool? initialized = ReadInitialized(initializedField, licenser);
            bool initializeCalled = false;

            if (forceInitialize && initialized != true)
            {
                MethodInfo? initializeMethod = licenserType.GetMethod(
                    "Initialize",
                    allInstanceFlags,
                    binder: null,
                    types: Type.EmptyTypes,
                    modifiers: null);
                if (initializeMethod == null)
                {
                    return new LicenseProbe(
                        initialized,
                        null,
                        null,
                        false,
                        "MCP licenser Initialize method is not available");
                }

                try
                {
                    initializeMethod.Invoke(licenser, null);
                    initializeCalled = true;
                    initialized = ReadInitialized(initializedField, licenser);
                }
                catch (TargetInvocationException exception)
                {
                    throw exception.InnerException ?? exception;
                }
            }

            bool? hard = InvokeBooleanMethod(
                licenserType,
                licenser,
                "IsLicensedHard");
            bool? soft = InvokeBooleanMethod(
                licenserType,
                licenser,
                "IsLicensedSoft");

            return new LicenseProbe(
                initialized,
                hard,
                soft,
                initializeCalled,
                "MCP licenser is available");
        }

        private static bool? ReadInitialized(
            FieldInfo? initializedField,
            object instance)
        {
            if (initializedField == null)
            {
                return null;
            }

            object? value = initializedField.GetValue(instance);
            if (value is int integer)
            {
                return integer != 0;
            }

            if (value is bool boolean)
            {
                return boolean;
            }

            return null;
        }

        private static bool? InvokeBooleanMethod(
            Type type,
            object instance,
            string methodName)
        {
            MethodInfo? method = type.GetMethod(
                methodName,
                BindingFlags.Public | BindingFlags.Instance,
                binder: null,
                types: Type.EmptyTypes,
                modifiers: null);
            if (method == null)
            {
                return null;
            }

            try
            {
                object? value = method.Invoke(instance, null);
                return value is bool result ? result : (bool?)null;
            }
            catch (TargetInvocationException exception)
            {
                throw exception.InnerException ?? exception;
            }
        }

        private static string StartMcpServer()
        {
            Assembly assembly = FindMcpImplementationAssembly()
                ?? throw new InvalidOperationException(
                    "DevelopmentSystemMCPServer.plugin is not loaded.");

            Type commandType = assembly.GetType(
                EnableCommandTypeName,
                throwOnError: true,
                ignoreCase: false)!;
            object command = Activator.CreateInstance(commandType)
                ?? throw new InvalidOperationException(
                    "Could not create the MCP Server command.");

            PropertyInfo? checkedProperty = commandType.GetProperty(
                "Checked",
                BindingFlags.Public | BindingFlags.Instance);
            if (checkedProperty?.GetValue(command, null) is bool alreadyRunning &&
                alreadyRunning)
            {
                return "MCP Server is already running.";
            }

            MethodInfo executeBatch = commandType.GetMethod(
                "ExecuteBatch",
                BindingFlags.Public | BindingFlags.Instance,
                binder: null,
                types: new[] { typeof(string[]) },
                modifiers: null)
                ?? throw new MissingMethodException(
                    commandType.FullName,
                    "ExecuteBatch(String[])");

            try
            {
                executeBatch.Invoke(
                    command,
                    new object[] { new[] { "true" } });
            }
            catch (TargetInvocationException exception)
            {
                throw exception.InnerException ?? exception;
            }

            if (checkedProperty?.GetValue(command, null) is bool running &&
                !running)
            {
                throw new InvalidOperationException(
                    "The MCP start command returned, but the command is not checked.");
            }

            return "MCP Server start command completed after license initialization.";
        }

        private static Assembly? FindMcpImplementationAssembly()
        {
            return AppDomain.CurrentDomain
                .GetAssemblies()
                .FirstOrDefault(
                    assembly => string.Equals(
                        assembly.GetName().Name,
                        McpAssemblyName,
                        StringComparison.OrdinalIgnoreCase));
        }

        private static void StopTimerLocked()
        {
            if (_timer != null)
            {
                _timer.Stop();
                _timer.Tick -= OnTimerTick;
                _timer.Dispose();
                _timer = null;
            }

            _elapsed?.Stop();
            _elapsed = null;
        }

        private static string GetAssemblyDirectory()
        {
            string? directory = Path.GetDirectoryName(
                typeof(McpServerAutoStarter).Assembly.Location);
            return string.IsNullOrEmpty(directory)
                ? Environment.CurrentDirectory
                : directory;
        }

        private static void WriteLog(string message)
        {
            string line = string.Format(
                "[{0:yyyy-MM-dd HH:mm:ss}] {1}",
                DateTime.Now,
                message);

            try
            {
                Console.WriteLine(line);
            }
            catch
            {
                // Logging must not interfere with CODESYS startup.
            }

            try
            {
                string path = _logPath ?? Path.Combine(
                    GetAssemblyDirectory(),
                    "startup-registration.log");
                File.AppendAllText(
                    path,
                    line + Environment.NewLine,
                    new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            }
            catch
            {
                // Logging must not interfere with CODESYS startup.
            }
        }

        private static string FormatException(Exception exception)
        {
            var builder = new StringBuilder();
            Exception? current = exception;
            int depth = 0;
            while (current != null && depth < 8)
            {
                if (depth > 0)
                {
                    builder.Append(" -> ");
                }

                builder.Append(current.GetType().FullName);
                builder.Append(": ");
                builder.Append(current.Message);
                current = current.InnerException;
                depth++;
            }

            return builder.ToString();
        }

        private sealed class LicenseProbe
        {
            public LicenseProbe(
                bool? initialized,
                bool? isLicensed,
                bool? isLicensedWithGrace,
                bool initializeCalled,
                string detail)
            {
                Initialized = initialized;
                IsLicensed = isLicensed;
                IsLicensedWithGrace = isLicensedWithGrace;
                InitializeCalled = initializeCalled;
                Detail = detail;
            }

            public bool? Initialized { get; }

            public bool? IsLicensed { get; }

            public bool? IsLicensedWithGrace { get; }

            public bool InitializeCalled { get; }

            public string Detail { get; }

            public override string ToString()
            {
                return string.Format(
                    "initialized={0}, hard={1}, soft={2}, " +
                    "initializeCalled={3}, detail={4}",
                    FormatNullableBoolean(Initialized),
                    FormatNullableBoolean(IsLicensed),
                    FormatNullableBoolean(IsLicensedWithGrace),
                    InitializeCalled,
                    Detail);
            }

            private static string FormatNullableBoolean(bool? value)
            {
                return value.HasValue ? value.Value.ToString() : "unknown";
            }
        }
    }
}
