# -*- coding: utf-8 -*-
from __future__ import print_function

from scriptengine import system

# CODESYS 3.5.22.20 binds the batch value correctly when it is passed as a
# string. Passing a Boolean or an explicit System.String[] selects the wrong
# ScriptCommand overload in this build.
system.commands[
    "ai_engineering_tools",
    "enable_mcp_stdio"].execute(str("true"))

print("MCP Server start command issued.")
