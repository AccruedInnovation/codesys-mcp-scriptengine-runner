# -*- coding: utf-8 -*-
from __future__ import print_function

from codesys_mcp_script_runner_common import invoke

print("MCP license state before requesting initialization:")
invoke("ProbeMcpLicenseState")

print("MCP license state after requesting the plug-in's normal Initialize method:")
invoke("InitializeAndProbeMcpLicenseState")
