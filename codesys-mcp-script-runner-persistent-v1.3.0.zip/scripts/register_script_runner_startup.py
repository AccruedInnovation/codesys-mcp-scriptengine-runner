# -*- coding: utf-8 -*-
from __future__ import print_function

import datetime
import os
import sys

try:
    from scriptengine import system as codesys_system
except Exception:
    codesys_system = None

script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

from codesys_mcp_script_runner_common import invoke

LOG_FILE = os.path.join(script_dir, "startup-registration.log")
REGISTER_MAX_ATTEMPTS = 20
REGISTER_RETRY_DELAY_MS = 250


def log(message):
    line = "[%s] %s" % (
        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        message)
    print(line)
    try:
        handle = open(LOG_FILE, "a")
        try:
            handle.write(line + "\n")
        finally:
            handle.close()
    except Exception:
        # Logging must not prevent normal CODESYS startup.
        pass


def format_exception_chain(exc):
    lines = []
    current = exc
    depth = 0
    while current is not None and depth < 12:
        try:
            type_name = current.GetType().FullName
        except Exception:
            type_name = type(current).__name__
        try:
            message = str(current.Message)
        except Exception:
            message = str(current)
        lines.append("%s: %s" % (type_name, message))
        try:
            current = current.InnerException
        except Exception:
            current = None
        depth += 1
    return " caused by: ".join(lines)


def wait_before_retry():
    if codesys_system is not None:
        # Registration already works at this stage, but a short retry protects
        # against a slow profile load. This delay is not used for MCP startup.
        codesys_system.delay(REGISTER_RETRY_DELAY_MS)
        return

    # Fallback for a host without the ScriptSystem object.
    import clr
    clr.AddReference("System")
    from System.Threading import Thread
    Thread.CurrentThread.Join(REGISTER_RETRY_DELAY_MS)


def register_script_runner_with_retry():
    last_error = None
    for attempt in range(1, REGISTER_MAX_ATTEMPTS + 1):
        try:
            result = invoke("RegisterScriptRunner")
            log("run_codesys_script registration completed.")
            if result is not None:
                log(str(result))
            return True
        except Exception as exc:
            last_error = exc
            if attempt < REGISTER_MAX_ATTEMPTS:
                wait_before_retry()

    log("run_codesys_script registration failed after %d attempts: %s" % (
        REGISTER_MAX_ATTEMPTS,
        format_exception_chain(last_error)))
    return False


register_script_runner_with_retry()

try:
    # The DLL owns a static Windows Forms timer. Its first callback cannot run
    # until this --runscript file has returned to the CODESYS UI message loop.
    # That lets the remaining system initializers, including the MCP licenser,
    # finish before the start command runs.
    invoke("ScheduleMcpServerStart")
except Exception as exc:
    log("Unable to schedule MCP Server startup: %s" % (
        format_exception_chain(exc)))
