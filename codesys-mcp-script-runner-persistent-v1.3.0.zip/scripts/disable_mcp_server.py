# -*- coding: utf-8 -*-
from __future__ import print_function

from scriptengine import system

system.commands[
    "ai_engineering_tools",
    "enable_mcp_stdio"].execute(str("false"))

print("MCP Server stop command issued.")
