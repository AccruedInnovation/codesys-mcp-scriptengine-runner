# Persistent CODESYS MCP Script Runner

Version 1.3.0 fixes MCP auto-start during CODESYS initialization.

The package registers `run_codesys_script` and starts the CODESYS MCP Server whenever CODESYS starts through a dedicated shortcut.

## Why the early license error occurs

CODESYS runs a `--runscript` file during IDE startup. In CODESYS 3.5.22.20, the ScriptEngine startup callback can run before the Development System MCP Server plug-in has completed its own license initialization.

Starting MCP from that callback can therefore show this dialog even when the PDE license works after the IDE finishes loading:

```text
Unable to start MCP server. Please activate your license.
```

Waiting inside the startup script is not enough. `system.delay()` serves the Windows message loop, but the startup script still has not returned from the current system-initializer callback. The later MCP initializer may remain pending.

Version 1.3.0 uses this order:

1. Register `run_codesys_script` immediately.
2. Schedule a static Windows Forms timer in the compiled helper DLL.
3. Return from the `--runscript` script.
4. On the CODESYS UI thread, poll the MCP plug-in's own `Licenser` state.
5. If required, call that licenser's guarded `Initialize()` method.
6. Start MCP only after `IsLicensedHard()` reports an active license.

This calls the normal MCP license path. It does not patch CODESYS, alter a license state, or bypass a missing license. It also does not call the lower-level private `LicenseChecker.CheckLicenses()` method.

## Compatibility

Tested and inspected against:

```text
CODESYS Development System: 3.5.22.20
Development System MCP Server: 1.1.0.0
.NET Framework target: 4.8
```

The deferred-start helper uses internal MCP 1.1.0.0 type and method names. A later MCP release may require an update.

## Install or update

1. Close every CODESYS instance.
2. Extract this archive to a stable local folder.
3. Find the normal CODESYS shortcut:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\tools\Find-CodesysShortcuts.ps1
```

4. Install or update the persistent launcher:

```powershell
.\tools\Install-PersistentLauncher.ps1 `
  -BaseShortcutPath "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\...\CODESYS....lnk" `
  -DesktopShortcut `
  -Confirm:$false
```

The runner files are copied by default to:

```text
%LOCALAPPDATA%\AccruedInnovation\CODESYS-MCP-ScriptRunner
```

The installer preserves the existing `user_scripts` directory and `script-root.txt` setting.

The generated shortcut adds:

```text
--runscript="<install directory>\register_script_runner_startup.py"
```

## Fast update from v1.2.x

Close CODESYS and replace **both** of these installed files:

```text
%LOCALAPPDATA%\AccruedInnovation\CODESYS-MCP-ScriptRunner\AccruedInnovation.CodesysMcp.ScriptRunner.dll
%LOCALAPPDATA%\AccruedInnovation\CODESYS-MCP-ScriptRunner\register_script_runner_startup.py
```

Replacing only the Python file is not enough because version 1.3.0 moves the deferred timer and license-state check into the DLL. Rerunning the installer is safer and also updates the probe and manual control scripts.

## Expected startup log

Read:

```text
%LOCALAPPDATA%\AccruedInnovation\CODESYS-MCP-ScriptRunner\startup-registration.log
```

Expected entries include:

```text
run_codesys_script registration completed.
MCP Server startup scheduled. The first check will run after the startup script returns to the CODESYS UI loop.
MCP Server start command completed after license initialization. License state: initialized=True, hard=True, ...
```

The helper polls every 500 ms for up to 120 seconds. It does not issue the start command while the hard license state is false. A missing or invalid license should therefore end in a log message rather than repeated startup dialogs.

## License-state probe

After CODESYS has loaded, run this through **Tools -> Scripting -> Execute Script File**:

```text
probe_mcp_license_state.py
```

It reports the state before and after calling the MCP plug-in's normal guarded `Initialize()` method.

The important fields are:

```text
initialized=True
hard=True
```

`soft` is the plug-in's grace-period state and is not used to authorize initial MCP startup.

## Manual start and stop

Run either file through **Tools -> Scripting -> Execute Script File**:

```text
scripts\enable_mcp_server.py
scripts\disable_mcp_server.py
```

For CODESYS 3.5.22.20, the ScriptCommand wrapper accepts the batch argument as a string:

```python
system.commands[
    "ai_engineering_tools",
    "enable_mcp_stdio"].execute(str("true"))
```

## Distinguishing startup order from a real license fault

After the IDE has fully opened, try the normal MCP toolbar button or run `enable_mcp_server.py`.

- If it works then, the startup dialog was an initialization-order fault and the deferred start is the right fix.
- If it still reports no license, check the Professional Developer Edition license, the selected CODESYS instance, the license container or network server, and the installed CODESYS License Provider components.

The package does not bypass a missing or invalid PDE license.

## Separate script directory

```powershell
.\tools\Install-PersistentLauncher.ps1 `
  -BaseShortcutPath "<normal CODESYS shortcut>" `
  -ScriptRoot "D:\Projects\codesys-mcp\approved-scripts" `
  -Confirm:$false
```

## Existing launch paths

The startup script runs only when CODESYS starts through the generated shortcut. Starting from another shortcut, CODESYS Installer, or a `.project` file association will not include `--runscript`.

## Remove

Remove generated shortcuts but retain scripts:

```powershell
.\tools\Uninstall-PersistentLauncher.ps1 -Confirm:$false
```

Remove shortcuts and all installed runner files:

```powershell
.\tools\Uninstall-PersistentLauncher.ps1 -Purge -Confirm:$false
```

## Source and validation

The `source` directory contains the C# project used for the compiled helper. See `BUILD-VALIDATION.md` for build inputs, hashes, and limits of the validation performed outside a live Windows CODESYS process.
