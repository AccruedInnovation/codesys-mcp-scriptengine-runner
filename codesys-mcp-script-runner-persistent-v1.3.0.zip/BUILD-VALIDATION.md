# Build and validation record

## Build target

```text
Assembly: AccruedInnovation.CodesysMcp.ScriptRunner.dll
Assembly version: 1.3.0.0
Target framework: .NET Framework 4.8
Platform: AnyCPU
```

## CODESYS references

The build used the assemblies collected from the user's CODESYS 3.5.22.20 installation:

```text
ComponentModel.dll
DevelopmentSystemMCPServer.dll 1.1.0.0
ScriptEngine3.dll
MessageStorage.dll
```

The CODESYS assemblies are reference-only and are not shipped in this package.

## Compiler

```text
.NET SDK 10.0.302, Linux x64
Microsoft.NETFramework.ReferenceAssemblies.net48 1.0.3
```

## Results

Two clean offline builds from separate source paths completed with:

```text
Warnings: 0
Errors: 0
```

Both builds produced matching DLL and PDB bytes.

```text
DLL SHA-256: 416f913fa0142f6e4c314e4efc3d7d4065a4f7342f085111c93a382534ed18ac
PDB SHA-256: 8642f36094e16dd387309373230d74c45a9029fc6a342cf9b4e5f3001e710a30
```

## Deferred startup behavior

Static inspection confirms that the DLL:

- keeps a Windows Forms timer in a static field;
- schedules the first check after the startup Python script returns to the UI loop;
- finds `DevelopmentSystemMCPServer.plugin` in the current AppDomain;
- reads the MCP plug-in's `Licenser` singleton;
- invokes the guarded internal `Initialize()` method only when `_initialized` is false;
- checks `IsLicensedHard()` and `IsLicensedSoft()`;
- invokes `EnableMcpServerCommand.ExecuteBatch(String[])` with `"true"` only after the hard license state is true;
- times out after 120 seconds;
- writes results to `startup-registration.log`.

It does not call `LicenseChecker.CheckLicenses()`, alter the returned state, patch a CODESYS binary, or suppress the normal MCP license check.

## Remaining live test

This environment cannot host the Windows CODESYS IDE. The following remain to be confirmed in the user's live CODESYS profile:

1. The timer callback runs after all system initializers complete.
2. The internal MCP 1.1.0.0 type names match the installed profile.
3. `EnableMcpServerCommand.ExecuteBatch(String[])` starts the server from the deferred UI-thread callback.
4. The active PDE license becomes `hard=True` after initialization.
