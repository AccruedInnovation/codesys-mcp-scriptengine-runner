[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
param(
    [string] $InstallDirectory =
        (Join-Path $env:LOCALAPPDATA 'AccruedInnovation\CODESYS-MCP-ScriptRunner'),

    [switch] $Purge
)

$ErrorActionPreference = 'Stop'
$resolvedInstallDirectory = [IO.Path]::GetFullPath(
    [Environment]::ExpandEnvironmentVariables($InstallDirectory))
$recordPath = Join-Path $resolvedInstallDirectory 'persistence-install.json'

$shortcutPaths = @()
if (Test-Path -LiteralPath $recordPath -PathType Leaf) {
    $record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
    if ($record.start_menu_shortcut) {
        $shortcutPaths += [string] $record.start_menu_shortcut
    }
    if ($record.desktop_shortcut) {
        $shortcutPaths += [string] $record.desktop_shortcut
    }
}

foreach ($path in ($shortcutPaths | Select-Object -Unique)) {
    if ((Test-Path -LiteralPath $path) -and
        $PSCmdlet.ShouldProcess(
            $path,
            'Remove persistent CODESYS launcher')) {
        Remove-Item -LiteralPath $path -Force
    }
}

if ($Purge -and (Test-Path -LiteralPath $resolvedInstallDirectory)) {
    if ($PSCmdlet.ShouldProcess(
        $resolvedInstallDirectory,
        'Remove runner files and user scripts')) {
        Remove-Item `
            -LiteralPath $resolvedInstallDirectory `
            -Recurse `
            -Force
    }
}
else {
    Write-Host "Runner files retained at: $resolvedInstallDirectory"
    Write-Host 'Use -Purge to remove that directory, including its user_scripts folder.'
}
