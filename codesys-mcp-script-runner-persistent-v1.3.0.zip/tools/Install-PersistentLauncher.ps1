[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
param(
    [Parameter(Mandatory = $true)]
    [ValidateScript({ Test-Path -LiteralPath $_ -PathType Leaf })]
    [string] $BaseShortcutPath,

    [string] $InstallDirectory =
        (Join-Path $env:LOCALAPPDATA 'AccruedInnovation\CODESYS-MCP-ScriptRunner'),

    [string] $ScriptRoot,

    [string] $ShortcutName = 'CODESYS with MCP Script Runner',

    [switch] $DesktopShortcut
)

$ErrorActionPreference = 'Stop'

function Copy-RunnerFile {
    param(
        [Parameter(Mandatory = $true)][string] $Name,
        [Parameter(Mandatory = $true)][string] $SourceDirectory,
        [Parameter(Mandatory = $true)][string] $DestinationDirectory
    )

    $source = Join-Path $SourceDirectory $Name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "Required package file is missing: $source"
    }
    Copy-Item -LiteralPath $source `
        -Destination (Join-Path $DestinationDirectory $Name) `
        -Force
}

$packageRoot = Split-Path -Parent $PSScriptRoot
$sourceScripts = Join-Path $packageRoot 'scripts'
$resolvedBaseShortcut = (Resolve-Path -LiteralPath $BaseShortcutPath).Path
$resolvedInstallDirectory = [IO.Path]::GetFullPath(
    [Environment]::ExpandEnvironmentVariables($InstallDirectory))

$wsh = New-Object -ComObject WScript.Shell
$base = $wsh.CreateShortcut($resolvedBaseShortcut)

if (-not $base.TargetPath -or
    -not (Test-Path -LiteralPath $base.TargetPath -PathType Leaf)) {
    throw "The base shortcut does not point to an existing executable: $resolvedBaseShortcut"
}
if ([IO.Path]::GetFileName($base.TargetPath) -ine 'CODESYS.exe') {
    throw "The base shortcut does not target CODESYS.exe: $($base.TargetPath)"
}
if ($base.Arguments -match '(?i)(^|\s)--runscript(?:=|\s)') {
    throw 'The base shortcut already contains --runscript. Use a normal CODESYS shortcut as the base.'
}

$startupScript = Join-Path $resolvedInstallDirectory 'register_script_runner_startup.py'
$startMenuDirectory = Join-Path `
    ([Environment]::GetFolderPath('Programs')) `
    'Accrued Innovation'
$startMenuShortcut = Join-Path `
    $startMenuDirectory `
    ($ShortcutName + '.lnk')
$desktopShortcutPath = if ($DesktopShortcut) {
    Join-Path `
        ([Environment]::GetFolderPath('DesktopDirectory')) `
        ($ShortcutName + '.lnk')
} else {
    $null
}

$plannedTargets = @($resolvedInstallDirectory, $startMenuShortcut)
if ($desktopShortcutPath) {
    $plannedTargets += $desktopShortcutPath
}

if (-not $PSCmdlet.ShouldProcess(
    ($plannedTargets -join '; '),
    'Install the MCP Script Runner files and persistent CODESYS launcher')) {
    return
}

New-Item -ItemType Directory -Path $resolvedInstallDirectory -Force | Out-Null
New-Item -ItemType Directory -Path $startMenuDirectory -Force | Out-Null

$runnerFiles = @(
    'AccruedInnovation.CodesysMcp.ScriptRunner.dll',
    'AccruedInnovation.CodesysMcp.ScriptRunner.pdb',
    'codesys_mcp_script_runner_common.py',
    'probe_script_runner.py',
    'probe_mcp_license_state.py',
    'register_script_runner.py',
    'register_script_runner_startup.py',
    'enable_mcp_server.py',
    'disable_mcp_server.py',
    'unregister_script_runner.py'
)
foreach ($name in $runnerFiles) {
    Copy-RunnerFile `
        -Name $name `
        -SourceDirectory $sourceScripts `
        -DestinationDirectory $resolvedInstallDirectory
}

$destinationUserScripts = Join-Path $resolvedInstallDirectory 'user_scripts'
New-Item -ItemType Directory -Path $destinationUserScripts -Force | Out-Null

$sampleScript = Join-Path $sourceScripts 'user_scripts\hello_mcp.py'
$destinationSample = Join-Path $destinationUserScripts 'hello_mcp.py'
if ((Test-Path -LiteralPath $sampleScript) -and
    -not (Test-Path -LiteralPath $destinationSample)) {
    Copy-Item -LiteralPath $sampleScript -Destination $destinationSample
}

$rootConfig = Join-Path $resolvedInstallDirectory 'script-root.txt'
if ($ScriptRoot) {
    $expandedScriptRoot = [IO.Path]::GetFullPath(
        [Environment]::ExpandEnvironmentVariables($ScriptRoot))
    New-Item -ItemType Directory -Path $expandedScriptRoot -Force | Out-Null
    Set-Content `
        -LiteralPath $rootConfig `
        -Value $expandedScriptRoot `
        -Encoding UTF8
}
elseif (-not (Test-Path -LiteralPath $rootConfig)) {
    Copy-RunnerFile `
        -Name 'script-root.txt' `
        -SourceDirectory $sourceScripts `
        -DestinationDirectory $resolvedInstallDirectory
}

$startupArgument = '--runscript="{0}"' -f $startupScript
$newArguments = (($base.Arguments.Trim() + ' ' + $startupArgument).Trim())

function Write-LauncherShortcut {
    param(
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    $shortcut = $wsh.CreateShortcut($Path)
    $shortcut.TargetPath = $base.TargetPath
    $shortcut.Arguments = $newArguments
    $shortcut.WorkingDirectory = if ($base.WorkingDirectory) {
        $base.WorkingDirectory
    } else {
        Split-Path -Parent $base.TargetPath
    }
    $shortcut.IconLocation = if ($base.IconLocation) {
        $base.IconLocation
    } else {
        $base.TargetPath + ',0'
    }
    $shortcut.Description =
        'Starts CODESYS, registers run_codesys_script, and enables the MCP server.'
    $shortcut.WindowStyle = $base.WindowStyle
    $shortcut.Save()
}

Write-LauncherShortcut -Path $startMenuShortcut
if ($desktopShortcutPath) {
    Write-LauncherShortcut -Path $desktopShortcutPath
}

$record = [ordered]@{
    version              = '1.3.0'
    installed_at         = (Get-Date).ToString('o')
    base_shortcut        = $resolvedBaseShortcut
    codesys_executable   = $base.TargetPath
    codesys_arguments    = $newArguments
    install_directory    = $resolvedInstallDirectory
    startup_script       = $startupScript
    start_menu_shortcut  = $startMenuShortcut
    desktop_shortcut     = $desktopShortcutPath
}
$record |
    ConvertTo-Json -Depth 4 |
    Set-Content `
        -LiteralPath (Join-Path $resolvedInstallDirectory 'persistence-install.json') `
        -Encoding UTF8

Write-Host "Installed runner files: $resolvedInstallDirectory"
Write-Host "Created shortcut: $startMenuShortcut"
if ($desktopShortcutPath) {
    Write-Host "Created shortcut: $desktopShortcutPath"
}
Write-Host 'Start CODESYS through the new shortcut. Tool registration and MCP server startup repeat on each IDE start.'
