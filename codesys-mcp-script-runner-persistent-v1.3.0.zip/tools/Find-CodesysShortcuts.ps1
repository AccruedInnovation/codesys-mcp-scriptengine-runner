[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$roots = @(
    [Environment]::GetFolderPath('CommonStartMenu'),
    [Environment]::GetFolderPath('StartMenu'),
    [Environment]::GetFolderPath('CommonDesktopDirectory'),
    [Environment]::GetFolderPath('DesktopDirectory')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

$wsh = New-Object -ComObject WScript.Shell
$results = foreach ($root in $roots) {
    Get-ChildItem -LiteralPath $root -Filter '*.lnk' -File -Recurse -ErrorAction SilentlyContinue |
        ForEach-Object {
            try {
                $shortcut = $wsh.CreateShortcut($_.FullName)
                if ($shortcut.TargetPath -and
                    ([IO.Path]::GetFileName($shortcut.TargetPath) -ieq 'CODESYS.exe')) {
                    [PSCustomObject]@{
                        ShortcutPath     = $_.FullName
                        TargetPath       = $shortcut.TargetPath
                        Arguments        = $shortcut.Arguments
                        WorkingDirectory = $shortcut.WorkingDirectory
                    }
                }
            }
            catch {
                Write-Verbose "Could not inspect shortcut '$($_.FullName)': $($_.Exception.Message)"
            }
        }
}

if (-not $results) {
    Write-Warning 'No Start Menu or desktop shortcut targeting CODESYS.exe was found.'
    return
}

$results | Sort-Object ShortcutPath | Format-List
